const PROFILE_STORAGE_KEY = 'quickqr-print-profiles'

window.addEventListener('message', async (event) => {
  if (event.source !== window) {
    return
  }

  if (event.origin !== 'https://nelsonllanes.com') {
    return
  }

  if (event.data?.source !== 'quick-qr-web') {
    return
  }

  if (event.data?.type !== 'QUICK_QR_SYNC') {
    return
  }

  const profiles = Array.isArray(event.data.profiles)
    ? event.data.profiles
    : []

  try {
    await chrome.storage.local.set({
      [PROFILE_STORAGE_KEY]: profiles,
    })

    window.postMessage(
      {
        source: 'quick-qr-extension',
        type: 'QUICK_QR_SYNC_RESULT',
        ok: true,
        profilesReceived: profiles.length,
      },
      window.location.origin,
    )

    console.log(`Quick QR: ${profiles.length} profile(s) synced.`)
  } catch (error) {
    console.error('Quick QR profile sync failed:', error)
  }
})