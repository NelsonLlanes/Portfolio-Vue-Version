const PENDING_SELECTION_KEY = 'quickqr-pending-selection'
const PROFILE_STORAGE_KEY = 'quickqr-print-profiles'

const QUICK_QR_URL = 'https://nelsonllanes.com/tools/quick-qr-code/'

// Context menu

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'quick-qr-generate',
    title: 'Quick QR',
    contexts: ['selection'],
  })
})

// Right click selection

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== 'quick-qr-generate') {
    return
  }

  const value = info.selectionText?.trim()

  if (!value) {
    return
  }

  await chrome.storage.local.set({
    [PENDING_SELECTION_KEY]: value,
  })

  try {
    await chrome.action.openPopup()
  } catch {
    // Popup can still be opened manually if the browser blocks it.
  }
})

// Keyboard shortcut

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'quick-generate') {
    return
  }

  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true,
  })

  if (!tab?.id) {
    return
  }

  try {
    const results = await chrome.scripting.executeScript({
      target: {
        tabId: tab.id,
      },

      func: () => window.getSelection()?.toString().trim() || '',
    })

    const value = results?.[0]?.result?.trim()

    if (value) {
      await chrome.storage.local.set({
        [PENDING_SELECTION_KEY]: value,
      })
    }

    try {
      await chrome.action.openPopup()
    } catch {
      // Popup can still be opened manually if the browser blocks it.
    }
  } catch (error) {
    console.error('Quick QR selection error:', error)
  }
})

// External messages

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message?.type === 'QUICK_QR_SYNC') {
    handleExternalSync(message, sender)
      .then((result) => {
        sendResponse(result)
      })
      .catch((error) => {
        console.error('Quick QR sync error:', error)

        sendResponse({
          ok: false,
          error: error.message || 'Could not sync Quick QR profiles.',
        })
      })

    return true
  }

  if (message?.type === 'QUICK_QR_OPEN_SHORTCUTS') {
    handleOpenShortcuts()
      .then(() => {
        sendResponse({
          ok: true,
        })
      })
      .catch((error) => {
        console.error('Could not open Chrome shortcuts:', error)

        sendResponse({
          ok: false,
          error: error.message || 'Could not open Chrome shortcut settings.',
        })
      })

    return true
  }
})

// Profile sync

async function handleExternalSync(message, sender) {
  const profiles = Array.isArray(message.profiles) ? message.profiles : []

  await chrome.storage.local.set({
    [PROFILE_STORAGE_KEY]: profiles,
  })

  console.log('Quick QR profiles synced.', {
    source: sender.origin || sender.url,
    profiles: profiles.length,
  })

  return {
    ok: true,
    profilesReceived: profiles.length,
  }
}

// Shortcut settings

async function handleOpenShortcuts() {
  await chrome.tabs.create({
    url: 'chrome://extensions/shortcuts',
  })
}